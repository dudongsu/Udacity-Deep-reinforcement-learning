# workspaces-student-support
Miscellaneous student support files for Udacity students using Workspaces.

Please look in the jupyter folder for the keep-alive script you can use to keep your Workspaces going for long periods.

